// Subscription check for premium features.
// Uses Supabase (table "subscribers") when configured. Otherwise falls back to
// the ACCESS_LIST environment variable, e.g. {"client@company.com":"Professional"}.
const sb = require('../lib/supabase');
const PAID_TIERS = ['Professional', 'Enterprise'];

const json = (statusCode, obj) => ({
  statusCode,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(obj),
});

async function tierFromSupabase(email) {
  const rows = await sb.select('subscribers', `email=eq.${encodeURIComponent(email)}&active=eq.true&select=tier`);
  return (rows[0] && rows[0].tier) || 'Free';
}

function tierFromEnv(email) {
  const raw = JSON.parse(process.env.ACCESS_LIST || '{}');
  const list = Object.fromEntries(Object.entries(raw).map(([k, v]) => [k.toLowerCase(), v]));
  return list[email] || 'Free';
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { authorized: false, tier: 'Free' });

  let email = '';
  try { email = String(JSON.parse(event.body || '{}').email || '').trim().toLowerCase(); } catch (e) { /* handled below */ }
  if (!email) return json(400, { authorized: false, tier: 'Free', error: 'email is required' });

  let tier;
  try {
    tier = sb.isConfigured() ? await tierFromSupabase(email) : tierFromEnv(email);
  } catch (e) {
    console.error('access check failed:', e.message);
    return json(500, { authorized: false, tier: 'Free', error: 'Subscription check unavailable' });
  }
  return json(200, { authorized: PAID_TIERS.includes(tier), tier });
};
