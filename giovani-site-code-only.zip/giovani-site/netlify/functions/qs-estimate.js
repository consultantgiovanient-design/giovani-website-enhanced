// Construction cost estimator with a machine-learning model.
//
// Model: ridge regression (closed-form, no external libraries) that predicts
// construction cost per m² from area, floors, building grade and feature level.
// It trains on your own project records supplied in the QS_TRAINING_JSON
// environment variable, e.g.
//   [{"area_sqm":4200,"floors":6,"grade":"Premium","features":"Smart Building","cost_per_sqm_kes":84000}, ...]
// It needs at least MIN_RECORDS records. Until then it uses the published
// Kenya base rates and says so in the response (method: "base-rates").

const MIN_RECORDS = 8;
const BASE = { Standard: 60000, Premium: 75000, Luxury: 90000, 'Ultra-Luxury': 120000 };
const GRADE_ORDER = { Standard: 1, Premium: 2, Luxury: 3, 'Ultra-Luxury': 4 };
const FEAT = { Basic: 1.0, 'Smart Building': 1.15, 'Green/Sustainable': 1.20, 'Specialty/Complex': 1.30 };

// East African markets: cost index and exchange rate are set in EA_COST_INDEX_JSON.
// index = construction cost relative to Kenya (Kenya = 1.0)
// fx    = local currency units per 1 KES
// Example: EA_COST_INDEX_JSON={"UG":{"index":0.95,"fx":28.4},"TZ":{"index":1.05,"fx":21.7}}
// Defaults below are placeholders (index 1.0, no fx) until you set real market values.
const COUNTRIES = {
  KE: { name: 'Kenya', currency: 'KES' },
  UG: { name: 'Uganda', currency: 'UGX' },
  TZ: { name: 'Tanzania', currency: 'TZS' },
  RW: { name: 'Rwanda', currency: 'RWF' },
  BI: { name: 'Burundi', currency: 'BIF' },
  SS: { name: 'South Sudan', currency: 'SSP' },
  ET: { name: 'Ethiopia', currency: 'ETB' },
};

function countryConfig() {
  try { return JSON.parse(process.env.EA_COST_INDEX_JSON || '{}'); } catch (e) { return {}; }
}

function localEquivalent(code, totalKES, perSqmKES) {
  const c = COUNTRIES[code];
  if (!c) return null;
  const cfg = countryConfig()[code] || {};
  const index = Number(cfg.index) > 0 ? Number(cfg.index) : 1;
  const fx = Number(cfg.fx) > 0 ? Number(cfg.fx) : null;
  const kesTotal = totalKES * index;
  const kesPerSqm = perSqmKES * index;
  return {
    country: c.name,
    currency: c.currency,
    costIndex: index,
    costPerSqmKES: Math.round(kesPerSqm),
    totalKES: Math.round(kesTotal),
    costPerSqmLocal: fx ? Math.round(kesPerSqm * fx) : null,
    totalLocal: fx ? Math.round(kesTotal * fx) : null,
    fxConfigured: !!fx,
  };
}

const json = (statusCode, obj) => ({
  statusCode,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(obj),
});

// Feature vector: intercept, log(area), floors, grade level, feature multiplier
const featuresOf = (r) => [1, Math.log(r.area_sqm), r.floors, GRADE_ORDER[r.grade], FEAT[r.features]];

// Solve A x = b by Gaussian elimination with partial pivoting
function solve(A, b) {
  const n = b.length;
  const M = A.map((row, i) => [...row, b[i]]);
  for (let i = 0; i < n; i++) {
    let p = i;
    for (let k = i + 1; k < n; k++) if (Math.abs(M[k][i]) > Math.abs(M[p][i])) p = k;
    [M[i], M[p]] = [M[p], M[i]];
    if (Math.abs(M[i][i]) < 1e-12) return null;
    for (let k = 0; k < n; k++) {
      if (k === i) continue;
      const f = M[k][i] / M[i][i];
      for (let j = i; j <= n; j++) M[k][j] -= f * M[i][j];
    }
  }
  return M.map((row, i) => row[n] / row[i]);
}

// Ridge regression: w = (XᵀX + λI)⁻¹ Xᵀy, intercept not penalised
function fitRidge(records, lambda = 1e-3) {
  const X = records.map(featuresOf);
  const y = records.map(r => Number(r.cost_per_sqm_kes));
  const k = X[0].length;
  const XtX = Array.from({ length: k }, () => new Array(k).fill(0));
  const Xty = new Array(k).fill(0);
  X.forEach((x, i) => {
    for (let a = 0; a < k; a++) {
      Xty[a] += x[a] * y[i];
      for (let b = 0; b < k; b++) XtX[a][b] += x[a] * x[b];
    }
  });
  for (let a = 1; a < k; a++) XtX[a][a] += lambda;
  const w = solve(XtX, Xty);
  if (!w) return null;
  const mean = y.reduce((s, v) => s + v, 0) / y.length;
  const ssTot = y.reduce((s, v) => s + (v - mean) ** 2, 0);
  const ssRes = X.reduce((s, x, i) => s + (x.reduce((t, xv, j) => t + xv * w[j], 0) - y[i]) ** 2, 0);
  return { w, r2: ssTot > 0 ? 1 - ssRes / ssTot : 0 };
}

const predict = (w, input) => featuresOf(input).reduce((s, xv, j) => s + xv * w[j], 0);

function loadTraining() {
  try {
    const rows = JSON.parse(process.env.QS_TRAINING_JSON || '[]');
    return rows.filter(r =>
      r && r.area_sqm > 0 && r.floors > 0 && GRADE_ORDER[r.grade] && FEAT[r.features] &&
      Number(r.cost_per_sqm_kes) > 0);
  } catch (e) { return []; }
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: 'Method not allowed' });

  let d;
  try { d = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { error: 'Invalid JSON' }); }

  const input = {
    area_sqm: Number(d.area),
    floors: Math.round(Number(d.floors)),
    grade: String(d.grade || 'Standard'),
    features: String(d.features || 'Basic'),
  };
  const contingency = Math.min(Math.max(Number(d.contingency) || 10, 0), 50);
  const country = String(d.country || 'KE').toUpperCase();

  if (!(input.area_sqm > 0 && input.area_sqm <= 1e6)) return json(400, { error: 'area must be between 0 and 1,000,000 m²' });
  if (!(input.floors >= 1 && input.floors <= 200)) return json(400, { error: 'floors must be between 1 and 200' });
  if (!BASE[input.grade]) return json(400, { error: 'unknown grade' });
  if (!FEAT[input.features]) return json(400, { error: 'unknown feature level' });

  const training = loadTraining();
  let costPerSqm = BASE[input.grade] * FEAT[input.features];
  let method = 'base-rates';
  let r2 = null;

  if (training.length >= MIN_RECORDS) {
    const model = fitRidge(training);
    if (model) {
      const floor = BASE[input.grade] * 0.5;
      const ceil = BASE[input.grade] * FEAT[input.features] * 2.5;
      costPerSqm = Math.min(Math.max(predict(model.w, input), floor), ceil);
      method = 'ml';
      r2 = Math.round(model.r2 * 1000) / 1000;
    }
  }

  const grossCost = input.area_sqm * costPerSqm;
  const contingencyAmount = grossCost * (contingency / 100);
  const totalCost = grossCost + contingencyAmount;

  return json(200, {
    local: localEquivalent(country, totalCost, costPerSqm),
    method,
    trainingRecords: training.length,
    r2,
    costPerSqm: Math.round(costPerSqm),
    grossCost: Math.round(grossCost),
    contingencyAmount: Math.round(contingencyAmount),
    totalCost: Math.round(totalCost),
    costPerFloor: Math.round(totalCost / input.floors),
    note: method === 'ml'
      ? `Estimate from a regression model trained on ${training.length} past projects (R² ${r2}).`
      : `Estimate from published Kenya base rates. The ML model activates after ${MIN_RECORDS} project records are supplied.`,
  });
};

exports.fitRidge = fitRidge;
exports.predict = predict;
