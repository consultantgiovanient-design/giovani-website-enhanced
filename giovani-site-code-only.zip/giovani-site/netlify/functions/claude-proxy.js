// Secure proxy to the Anthropic API. The key lives in the ANTHROPIC_API_KEY
// environment variable on Netlify and is never sent to the browser.
const ALLOWED_MODEL = /^claude-[a-z0-9.\-]+$/;
const WINDOW_MS = 5 * 60 * 1000;
const MAX_REQUESTS = 20;
const hits = new Map(); // per-instance, best-effort rate limit

const json = (statusCode, obj) => ({
  statusCode,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(obj),
});

function clientIp(event) {
  const h = event.headers || {};
  return (h['x-nf-client-connection-ip'] || h['client-ip'] || h['x-forwarded-for'] || 'unknown')
    .split(',')[0].trim();
}

function rateLimited(ip) {
  const now = Date.now();
  const recent = (hits.get(ip) || []).filter(t => now - t < WINDOW_MS);
  if (recent.length >= MAX_REQUESTS) { hits.set(ip, recent); return true; }
  recent.push(now);
  hits.set(ip, recent);
  return false;
}

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { error: { message: 'Method not allowed' } });

  const key = process.env.ANTHROPIC_API_KEY;
  if (!key) return json(503, { error: { message: 'AI service is not configured yet.' } });

  if (rateLimited(clientIp(event))) return json(429, { error: { message: 'Too many requests' } });

  let body;
  try { body = JSON.parse(event.body || '{}'); }
  catch (e) { return json(400, { error: { message: 'Invalid JSON' } }); }

  const model = String(body.model || 'claude-sonnet-4-6');
  if (!ALLOWED_MODEL.test(model)) return json(400, { error: { message: 'Model not allowed' } });
  if (!Array.isArray(body.messages) || body.messages.length === 0) {
    return json(400, { error: { message: 'messages is required' } });
  }

  const messages = body.messages.slice(-20).map(m => ({
    role: ['assistant', 'bot', 'model'].includes(m.role) ? 'assistant' : 'user',
    content: String(m.content || '').slice(0, 8000),
  }));

  const payload = {
    model,
    max_tokens: Math.min(Number(body.max_tokens) || 500, 1000),
    messages,
  };
  if (body.system) payload.system = String(body.system).slice(0, 12000);

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
      },
      body: JSON.stringify(payload),
    });
    const text = await r.text();
    try { JSON.parse(text); }
    catch (e) { return json(502, { error: { message: 'AI upstream returned an unexpected response' } }); }
    return { statusCode: r.status, headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' }, body: text };
  } catch (e) {
    return json(502, { error: { message: 'AI upstream unavailable' } });
  }
};
