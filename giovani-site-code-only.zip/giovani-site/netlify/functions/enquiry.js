// Receives website enquiries. Saves them to Supabase when configured, emails the
// firm and sends an automatic acknowledgement to the client via Resend.
const sb = require('../lib/supabase');
const { sendMail } = require('../lib/mail');
const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

const json = (statusCode, obj) => ({
  statusCode,
  headers: { 'Content-Type': 'application/json', 'Cache-Control': 'no-store' },
  body: JSON.stringify(obj),
});
const clean = (v, max) => String(v || '').replace(/[\r\n]+/g, ' ').trim().slice(0, max);

exports.handler = async (event) => {
  if (event.httpMethod !== 'POST') return json(405, { sent: false });

  let d;
  try { d = JSON.parse(event.body || '{}'); } catch (e) { return json(400, { sent: false, error: 'Invalid JSON' }); }
  if (d.website) return json(200, { sent: true }); // honeypot: bots only

  const row = {
    type: clean(d.type, 40) || 'enquiry',
    name: clean(d.name, 120),
    organization: clean(d.organization, 160) || null,
    email: clean(d.email, 200).toLowerCase(),
    phone: clean(d.phone, 40) || null,
    interest: clean(d.interest, 120) || null,
  };
  if (!row.name || !EMAIL_RE.test(row.email)) {
    return json(400, { sent: false, error: 'A name and a valid email are required.' });
  }

  let saved = false;
  if (sb.isConfigured()) {
    try { await sb.insert('enquiries', row); saved = true; }
    catch (e) { console.error('enquiry save failed:', e.message); }
  }

  if (!process.env.RESEND_API_KEY) {
    // Saved to the database is a success; otherwise the site falls back to Gmail/WhatsApp
    return json(200, { sent: saved, saved, reason: saved ? 'saved' : 'mail-not-configured' });
  }

  try {
    const firmOk = await sendMail({
      to: process.env.MAIL_TO || 'info@consultantgiovanienterprises.co.ke',
      replyTo: row.email,
      subject: `[Website ${row.type}] ${row.name}${row.organization ? ' — ' + row.organization : ''}`,
      text: [
        `Type: ${row.type}`, `Name: ${row.name}`, `Organization: ${row.organization || '-'}`,
        `Email: ${row.email}`, `Phone/WhatsApp: ${row.phone || '-'}`, `Interest: ${row.interest || '-'}`,
      ].join('\n'),
    });
    // Automatic acknowledgement to the client
    await sendMail({
      to: row.email,
      subject: 'Thank you for contacting Giovani Enterprises',
      text: [
        `Dear ${row.name},`, '',
        'Thank you for your request. Our team has received it and will respond within one business day.',
        'For anything urgent, WhatsApp us on +254 720 799 955.', '',
        'Giovani Enterprises Consultants Ltd, Nairobi, Kenya',
      ].join('\n'),
    }).catch(() => false);

    if (!firmOk && !saved) return json(502, { sent: false, reason: 'mail-provider-error' });
    return json(200, { sent: true, saved });
  } catch (e) {
    console.error('enquiry mail failed:', e.message);
    return json(saved ? 200 : 502, { sent: saved, saved, reason: 'mail-provider-unreachable' });
  }
};
