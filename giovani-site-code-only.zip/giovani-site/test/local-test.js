// Runs each Netlify Function handler with mock events. No network needed.
const assert = require('assert');
const proxy = require('../netlify/functions/claude-proxy').handler;
const access = require('../netlify/functions/verify-access').handler;
const enquiry = require('../netlify/functions/enquiry').handler;
const qs = require('../netlify/functions/qs-estimate');
const ev = (body, method = 'POST', headers = {}) => ({ httpMethod: method, body: JSON.stringify(body), headers });

(async () => {
  let pass = 0;
  const t = async (name, fn) => { await fn(); pass++; console.log('  ok  ', name); };

  await t('proxy: 405 on GET', async () => {
    assert.equal((await proxy({ httpMethod: 'GET' })).statusCode, 405);
  });
  await t('proxy: 503 when ANTHROPIC_API_KEY missing (key never leaks)', async () => {
    delete process.env.ANTHROPIC_API_KEY;
    const r = await proxy(ev({ messages: [{ role: 'user', content: 'hi' }] }));
    assert.equal(r.statusCode, 503);
  });
  await t('proxy: rejects bad model and empty messages', async () => {
    process.env.ANTHROPIC_API_KEY = 'test-key';
    assert.equal((await proxy(ev({ model: 'gpt-4', messages: [{ role: 'user', content: 'x' }] }))).statusCode, 400);
    assert.equal((await proxy(ev({ messages: [] }))).statusCode, 400);
  });
  await t('proxy: forwards to upstream (network blocked here -> 502, handled cleanly)', async () => {
    const r = await proxy(ev({ messages: [{ role: 'user', content: 'hi' }] }, 'POST', { 'client-ip': '1.2.3.4' }));
    assert.ok([200, 401, 403, 502].includes(r.statusCode), 'got ' + r.statusCode); assert.ok(JSON.parse(r.body));
  });
  await t('proxy: rate limit after 20 requests', async () => {
    let last;
    for (let i = 0; i < 25; i++) last = await proxy(ev({ messages: [{ role: 'user', content: 'x' }] }, 'POST', { 'client-ip': '9.9.9.9' }));
    assert.equal(last.statusCode, 429);
  });

  await t('access: free user is not authorised', async () => {
    process.env.ACCESS_LIST = JSON.stringify({ 'pro@client.co': 'Professional' });
    const r = JSON.parse((await access(ev({ email: 'nobody@x.com' }))).body);
    assert.equal(r.authorized, false); assert.equal(r.tier, 'Free');
  });
  await t('access: Professional email is authorised (case-insensitive)', async () => {
    const r = JSON.parse((await access(ev({ email: 'PRO@client.co' }))).body);
    assert.equal(r.authorized, true);
  });
  await t('access: bad ACCESS_LIST returns 500, not a crash', async () => {
    process.env.ACCESS_LIST = '{not json';
    assert.equal((await access(ev({ email: 'a@b.co' }))).statusCode, 500);
  });

  await t('enquiry: rejects missing name / invalid email', async () => {
    assert.equal((await enquiry(ev({ name: '', email: 'a@b.co' }))).statusCode, 400);
    assert.equal((await enquiry(ev({ name: 'Ann', email: 'not-an-email' }))).statusCode, 400);
  });
  await t('enquiry: honeypot silently accepts bots', async () => {
    const r = JSON.parse((await enquiry(ev({ website: 'spam', name: 'x', email: 'a@b.co' }))).body);
    assert.equal(r.sent, true);
  });
  await t('enquiry: without RESEND_API_KEY the site falls back (sent:false)', async () => {
    delete process.env.RESEND_API_KEY;
    const r = JSON.parse((await enquiry(ev({ name: 'Ann', email: 'ann@x.co', interest: 'ISO' }))).body);
    assert.equal(r.sent, false); assert.equal(r.reason, 'mail-not-configured');
  });

  await t('qs: no training data -> base-rate method (Premium 75,000/m²)', async () => {
    delete process.env.QS_TRAINING_JSON;
    const r = JSON.parse((await qs.handler(ev({ area: 1000, floors: 5, grade: 'Premium', features: 'Basic', contingency: 10 }))).body);
    assert.equal(r.method, 'base-rates'); assert.equal(r.costPerSqm, 75000);
    assert.equal(r.totalCost, Math.round(1000 * 75000 * 1.1));
  });
  await t('qs: rejects bad input', async () => {
    assert.equal((await qs.handler(ev({ area: -5, floors: 3, grade: 'Premium', features: 'Basic' }))).statusCode, 400);
    assert.equal((await qs.handler(ev({ area: 100, floors: 3, grade: 'Palace', features: 'Basic' }))).statusCode, 400);
  });
  await t('qs: ML learns a known pattern from synthetic records (check of the regression itself)', async () => {
    // Synthetic ground truth: cost = 60000 * featureMult * (1 + 0.1*(gradeLevel-1)) + small noise
    const G = { Standard: 1, Premium: 2, Luxury: 3, 'Ultra-Luxury': 4 };
    const F = { Basic: 1.0, 'Smart Building': 1.15, 'Green/Sustainable': 1.20, 'Specialty/Complex': 1.30 };
    const grades = Object.keys(G), feats = Object.keys(F);
    const rows = [];
    for (let i = 0; i < 40; i++) {
      const g = grades[i % 4], f = feats[(i * 3) % 4], area = 500 + i * 150, floors = 2 + (i % 12);
      const truth = 60000 * F[f] * (1 + 0.1 * (G[g] - 1));
      const noise = ((i * 37) % 11 - 5) * 100;
      rows.push({ area_sqm: area, floors, grade: g, features: f, cost_per_sqm_kes: Math.round(truth + noise) });
    }
    process.env.QS_TRAINING_JSON = JSON.stringify(rows);
    const r = JSON.parse((await qs.handler(ev({ area: 2000, floors: 8, grade: 'Luxury', features: 'Green/Sustainable' }))).body);
    assert.equal(r.method, 'ml');
    const truth = 60000 * 1.20 * (1 + 0.1 * 2);
    assert.ok(Math.abs(r.costPerSqm - truth) / truth < 0.05, `prediction ${r.costPerSqm} vs truth ${truth}`);
    assert.ok(r.r2 > 0.95, 'R² should be high on clean synthetic data');
    console.log(`        ML prediction ${r.costPerSqm} vs truth ${Math.round(truth)}, R² ${r.r2}`);
  });
  await t('qs: fewer than 8 records falls back to base rates', async () => {
    process.env.QS_TRAINING_JSON = JSON.stringify([{ area_sqm: 1000, floors: 3, grade: 'Standard', features: 'Basic', cost_per_sqm_kes: 61000 }]);
    const r = JSON.parse((await qs.handler(ev({ area: 1000, floors: 3, grade: 'Standard', features: 'Basic' }))).body);
    assert.equal(r.method, 'base-rates');
  });

  console.log(`\n${pass} tests passed`);
})().catch(e => { console.error('FAILED:', e.message); process.exit(1); });
