// Tests Supabase, image providers (with fallback), mail and East Africa cost conversion.
// External services are mocked, so no network or keys are needed.
const assert = require('assert');
const calls = [];
let routes = [];

function mockFetch() {
  global.fetch = async (url, opts = {}) => {
    calls.push({ url: String(url), method: opts.method || 'GET', body: opts.body });
    const route = routes.find(r => r.match.test(String(url)));
    if (!route) throw new Error('unmocked request: ' + url);
    const res = typeof route.reply === 'function' ? route.reply(String(url), opts) : route.reply;
    const bytes = res.bytes ? Buffer.from(res.bytes) : null;
    return {
      ok: res.status >= 200 && res.status < 300,
      status: res.status,
      headers: { get: k => (res.headers || {})[k.toLowerCase()] || null },
      json: async () => res.json,
      text: async () => (bytes ? bytes.toString() : JSON.stringify(res.json || '')),
      arrayBuffer: async () => (bytes ? bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength) : new ArrayBuffer(0)),
    };
  };
}
const ev = (body, headers = {}) => ({ httpMethod: 'POST', body: JSON.stringify(body), headers });
const clearEnv = () => ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY', 'OPENAI_API_KEY', 'STABILITY_API_KEY',
  'REPLICATE_API_TOKEN', 'RESEND_API_KEY', 'PROFESSIONAL_REVIEW_EMAIL', 'ACCESS_LIST', 'EA_COST_INDEX_JSON',
  'IMAGE_DAILY_LIMIT', 'IMAGE_PROVIDER_ORDER'].forEach(k => delete process.env[k]);
const SB = 'https://proj.supabase.co';

(async () => {
  mockFetch();
  let pass = 0;
  const t = async (name, fn) => { clearEnv(); routes = []; calls.length = 0; await fn(); pass++; console.log('  ok  ', name); };

  const access = require('../netlify/functions/verify-access').handler;
  const enquiry = require('../netlify/functions/enquiry').handler;
  const design = require('../netlify/functions/design-image');
  const qs = require('../netlify/functions/qs-estimate');

  await t('supabase access: paid subscriber found by lowercase email', async () => {
    process.env.SUPABASE_URL = SB; process.env.SUPABASE_SERVICE_ROLE_KEY = 'srk';
    routes = [{ match: /rest\/v1\/subscribers/, reply: { status: 200, json: [{ tier: 'Professional' }] } }];
    const r = JSON.parse((await access(ev({ email: 'Client@Firm.co' }))).body);
    assert.equal(r.authorized, true);
    assert.ok(calls[0].url.includes('email=eq.client%40firm.co'), calls[0].url);
    assert.ok(calls[0].url.includes('active=eq.true'));
  });
  await t('supabase access: unknown email is Free', async () => {
    process.env.SUPABASE_URL = SB; process.env.SUPABASE_SERVICE_ROLE_KEY = 'srk';
    routes = [{ match: /rest\/v1\/subscribers/, reply: { status: 200, json: [] } }];
    const r = JSON.parse((await access(ev({ email: 'x@y.co' }))).body);
    assert.equal(r.authorized, false); assert.equal(r.tier, 'Free');
  });
  await t('supabase access: database error returns 500, not a crash', async () => {
    process.env.SUPABASE_URL = SB; process.env.SUPABASE_SERVICE_ROLE_KEY = 'srk';
    routes = [{ match: /rest\/v1\/subscribers/, reply: { status: 500, json: {} } }];
    assert.equal((await access(ev({ email: 'x@y.co' }))).statusCode, 500);
  });

  await t('enquiry: saved to Supabase with lowercase email, success without email provider', async () => {
    process.env.SUPABASE_URL = SB; process.env.SUPABASE_SERVICE_ROLE_KEY = 'srk';
    routes = [{ match: /rest\/v1\/enquiries/, reply: { status: 201, json: {} } }];
    const r = JSON.parse((await enquiry(ev({ name: 'Ann', email: 'ANN@X.CO', interest: 'ISO 27001' }))).body);
    assert.equal(r.sent, true); assert.equal(r.saved, true);
    const row = JSON.parse(calls[0].body);
    assert.equal(row.email, 'ann@x.co');
  });
  await t('enquiry: emails firm and client when Resend is set', async () => {
    process.env.SUPABASE_URL = SB; process.env.SUPABASE_SERVICE_ROLE_KEY = 'srk';
    process.env.RESEND_API_KEY = 're_test';
    routes = [
      { match: /rest\/v1\/enquiries/, reply: { status: 201, json: {} } },
      { match: /api\.resend\.com/, reply: { status: 200, json: { id: 'x' } } },
    ];
    const r = JSON.parse((await enquiry(ev({ name: 'Ann', email: 'ann@x.co' }))).body);
    assert.equal(r.sent, true);
    const mails = calls.filter(c => c.url.includes('resend.com'));
    assert.equal(mails.length, 2, 'firm notification + client acknowledgement');
    assert.deepEqual(JSON.parse(mails[1].body).to, ['ann@x.co']);
  });

  await t('design: 503 with no image provider keys, and no key values in the response', async () => {
    const r = await design.handler(ev({ projectType: 'Villa', brief: 'x' }));
    assert.equal(r.statusCode, 503);
    assert.ok(!/sk-|st-|re_/.test(r.body), 'no key-like strings in response');
  });
  await t('design: OpenAI generates sketch and it is returned as an image', async () => {
    process.env.OPENAI_API_KEY = 'sk-test';
    routes = [{ match: /api\.openai\.com/, reply: { status: 200, json: { data: [{ b64_json: Buffer.from('PNGDATA').toString('base64') }] } } }];
    const r = JSON.parse((await design.handler(ev({ projectType: 'Villa', location: 'Nairobi', renderMode: '3D Exterior Render' }))).body);
    assert.equal(r.provider, 'openai');
    assert.ok(r.image.startsWith('data:image/png;base64,'));
    assert.ok(r.label.includes('Concept only'));
  });
  await t('design: falls back to Stability when OpenAI fails', async () => {
    process.env.OPENAI_API_KEY = 'sk-test'; process.env.STABILITY_API_KEY = 'st-test';
    routes = [
      { match: /api\.openai\.com/, reply: { status: 500, json: { error: { message: 'busy' } } } },
      { match: /api\.stability\.ai/, reply: { status: 200, bytes: Buffer.from('JPEGISH'), headers: { 'content-type': 'image/png' } } },
    ];
    const r = JSON.parse((await design.handler(ev({ projectType: 'Villa' }))).body);
    assert.equal(r.provider, 'stability');
  });
  await t('design: Replicate used as the third fallback', async () => {
    process.env.OPENAI_API_KEY = 'a'; process.env.STABILITY_API_KEY = 'b'; process.env.REPLICATE_API_TOKEN = 'c';
    routes = [
      { match: /api\.openai\.com/, reply: { status: 429, json: { error: { message: 'rate' } } } },
      { match: /api\.stability\.ai/, reply: { status: 402, json: {} } },
      { match: /api\.replicate\.com/, reply: { status: 201, json: { output: ['https://cdn.replicate.example/img.png'] } } },
      { match: /cdn\.replicate\.example/, reply: { status: 200, bytes: Buffer.from('IMG'), headers: { 'content-type': 'image/png' } } },
    ];
    const r = JSON.parse((await design.handler(ev({ projectType: 'Villa' }))).body);
    assert.equal(r.provider, 'replicate');
  });
  await t('design: sketch stored in Supabase Storage and request logged', async () => {
    process.env.OPENAI_API_KEY = 'sk-test';
    process.env.SUPABASE_URL = SB; process.env.SUPABASE_SERVICE_ROLE_KEY = 'srk';
    routes = [
      { match: /api\.openai\.com/, reply: { status: 200, json: { data: [{ b64_json: Buffer.from('P').toString('base64') }] } } },
      { match: /storage\/v1\/object\/design-sketches/, reply: { status: 200, json: {} } },
      { match: /rest\/v1\/design_requests/, reply: { status: 201, json: {} } },
      { match: /rest\/v1\/design_requests\?created_at/, reply: { status: 200, json: [], headers: { 'content-range': '0-0/0' } } },
    ];
    const r = JSON.parse((await design.handler(ev({ projectType: 'Villa' }))).body);
    assert.equal(r.stored, true);
    assert.ok(calls.some(c => c.url.includes('/storage/v1/object/design-sketches/')));
    assert.ok(calls.some(c => c.url.endsWith('/rest/v1/design_requests') && c.method === 'POST'));
  });
  await t('design: professional reviewer is emailed for every generated sketch', async () => {
    process.env.OPENAI_API_KEY = 'sk-test'; process.env.RESEND_API_KEY = 're';
    process.env.PROFESSIONAL_REVIEW_EMAIL = 'architect@firm.co';
    routes = [
      { match: /api\.openai\.com/, reply: { status: 200, json: { data: [{ b64_json: Buffer.from('P').toString('base64') }] } } },
      { match: /api\.resend\.com/, reply: { status: 200, json: {} } },
    ];
    await design.handler(ev({ projectType: 'Villa' }));
    const m = calls.find(c => c.url.includes('resend.com'));
    assert.deepEqual(JSON.parse(m.body).to, ['architect@firm.co']);
  });
  await t('design: prompts switch for interior and landscape, always marked concept-only', async () => {
    const i = design.buildPrompt({ projectType: 'Flat', location: 'Nairobi', style: 'x', renderMode: '3D Interior Render', brief: '' });
    const l = design.buildPrompt({ projectType: 'Estate', location: 'Kisumu', style: 'x', renderMode: 'Landscape Design', brief: '' });
    assert.ok(/interior/.test(i)); assert.ok(/landscape/.test(l));
    assert.ok(/No text/.test(i));
  });

  await t('cost: Kenya base KES 60,000/m² Standard', async () => {
    const r = JSON.parse((await qs.handler(ev({ area: 1000, floors: 4, grade: 'Standard', features: 'Basic', country: 'KE' }))).body);
    assert.equal(r.costPerSqm, 60000);
    assert.equal(r.local.currency, 'KES');
    assert.equal(r.local.totalKES, Math.round(1000 * 60000 * 1.1));
  });
  await t('cost: Uganda converted with index and exchange rate', async () => {
    process.env.EA_COST_INDEX_JSON = JSON.stringify({ UG: { index: 0.95, fx: 28.4 } });
    const r = JSON.parse((await qs.handler(ev({ area: 1000, floors: 4, grade: 'Standard', features: 'Basic', country: 'UG' }))).body);
    const kes = 1000 * 60000 * 1.1;
    assert.equal(r.local.currency, 'UGX');
    assert.equal(r.local.totalLocal, Math.round(kes * 0.95 * 28.4));
  });
  await t('cost: country without exchange rate shows KES and says so', async () => {
    const r = JSON.parse((await qs.handler(ev({ area: 500, floors: 2, grade: 'Standard', features: 'Basic', country: 'TZ' }))).body);
    assert.equal(r.local.fxConfigured, false); assert.equal(r.local.totalLocal, null);
  });
  await t('cost: unknown country is ignored safely', async () => {
    const r = JSON.parse((await qs.handler(ev({ area: 500, floors: 2, grade: 'Standard', features: 'Basic', country: 'XX' }))).body);
    assert.equal(r.local, null); assert.equal(r.costPerSqm, 60000);
  });

  await t('design: daily limit enforced when Supabase is not configured', async () => {
    // Fresh module instance so the in-memory counter starts at zero
    delete require.cache[require.resolve('../netlify/functions/design-image')];
    const fresh = require('../netlify/functions/design-image').handler;
    process.env.OPENAI_API_KEY = 'sk-test'; process.env.IMAGE_DAILY_LIMIT = '1';
    routes = [{ match: /api\.openai\.com/, reply: { status: 200, json: { data: [{ b64_json: Buffer.from('P').toString('base64') }] } } }];
    const first = await fresh(ev({ projectType: 'Villa' }));
    const second = await fresh(ev({ projectType: 'Villa' }));
    assert.equal(first.statusCode, 200); assert.equal(second.statusCode, 429);
  });

  console.log(`\n${pass} integration tests passed`);
})().catch(e => { console.error('FAILED:', e.message); process.exit(1); });
